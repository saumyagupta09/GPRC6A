# GPRC6A Ruminantia comparative-genomics pipeline

This bundle is prepared for the uploaded pig GPRC6A exon FASTA and the ruminant assemblies extracted from `ncbi_dataset.tsv`.

## Prepared inputs

- `ruminantia_assemblies.tsv`: 672 assembly accessions, retaining all accessions in the supplied genome list, including paired GCA/GCF representations unless you explicitly request deduplication.
- `ruminantia_species_tree.newick`: rooted consensus tree with 105 species-level ruminant tips. Subspecies/infraspecific assembly labels are collapsed to their binomial species for phylogenetic inference. Hybrids are analyzed at assembly level but are not forced onto a bifurcating species tree.
- Pig reference exon FASTA: use your uploaded `Sus_scrofa_XM_021089187.1_exons(1).fa`.

The supplied pig exons concatenate to 2,787 nt, 929 codons, with one terminal stop and no internal stop in the reference sequence.

## Required software

Python packages:

```bash
pip install pandas biopython
```

External command-line tools:

- NCBI BLAST+ (`blastn`)
- NCBI Datasets CLI (`datasets`) unless all genome FASTAs are supplied locally with `--genome-map`
- RepeatMasker is optional but strongly recommended for transposable-element/repeat-family annotation

Check them with:

```bash
blastn -version
datasets version
RepeatMasker -version    # optional
```

## Recommended test run

Always test a few assemblies before launching all 672:

```bash
python gprc6a_ruminant_pipeline.py \
  --targets-tsv ruminantia_assemblies.tsv \
  --exons 'Sus_scrofa_XM_021089187.1_exons(1).fa' \
  --tree ruminantia_species_tree.newick \
  --outdir GPRC6A_Ruminantia \
  --max-assemblies 3 \
  --workers 1 \
  --blast-threads 8 \
  --resume
```

Inspect `GPRC6A_Ruminantia/report.html`, the raw BLAST files, and the assembly event tables before scaling up.

## Full run over every listed ruminant assembly

```bash
python gprc6a_ruminant_pipeline.py \
  --targets-tsv ruminantia_assemblies.tsv \
  --exons 'Sus_scrofa_XM_021089187.1_exons(1).fa' \
  --tree ruminantia_species_tree.newick \
  --outdir GPRC6A_Ruminantia \
  --workers 2 \
  --blast-threads 8 \
  --repeat-threads 8 \
  --resume \
  --cleanup-genomes
```

Do **not** add `--drop-paired-duplicates` if you want every accession in the supplied list searched. Add it only if you want to avoid re-analyzing paired GenBank/RefSeq representations of the same assembly.

`--cleanup-genomes` removes downloaded genome packages after successful analysis but retains the raw BLAST output and the per-assembly JSON call set. Omit it if you want the genome FASTAs cached for manual validation.

## Using already-downloaded genomes

Prepare a two-column TSV:

```text
Assembly Accession\tGenome FASTA
GCF_012345678.1\t/data/genomes/GCF_012345678.1_genomic.fna
...
```

Then run with:

```bash
--genome-map genome_paths.tsv
```

Any accession not present in the map is downloaded with NCBI Datasets if `datasets` is installed.

## HPC/job-array mode

Multiple shards can write assembly results into the same output directory because every assembly has its own directory. Suppress report generation on the workers:

```bash
python gprc6a_ruminant_pipeline.py ... \
  --outdir GPRC6A_Ruminantia \
  --num-shards 16 \
  --shard-index 0 \
  --skip-report \
  --resume
```

Run shard indices 0 through 15. After all shards finish, build one combined report using the full target table:

```bash
python gprc6a_ruminant_pipeline.py \
  --targets-tsv ruminantia_assemblies.tsv \
  --exons 'Sus_scrofa_XM_021089187.1_exons(1).fa' \
  --tree ruminantia_species_tree.newick \
  --outdir GPRC6A_Ruminantia \
  --report-only
```

## Main outputs

Each assembly gets:

```text
assemblies/<ACCESSION>/blast.tsv.gz
assemblies/<ACCESSION>/analysis.json
```

Final tables include:

- `assembly_locus_summary.tsv`: selected orthologous locus, strand, coordinates, locus score, N-content.
- `assembly_exon_metrics.tsv`: recovered fraction, aligned fraction, callable fraction, identity, local N-content, confidence, splice motifs for every exon of every assembly.
- `assembly_events.tsv`: frame-shifting indels, in-frame indels, premature stops, frame-shift-induced stops, start/stop loss, probable exon deletions, unresolved exons, potential splice-site disruptions.
- `assembly_all_variants.tsv`: substitutions and other sequence differences, including exon/CDS/codon positions where definable.
- `species_exon_summary.tsv`: cross-assembly exon recovery/confidence for each species.
- `species_events.tsv`: assembly-supported species consensus events.
- `phylogenetic_event_summary.tsv`: shared-event groups, MRCA, parsimony score, inferred minimum origins/reversions, and relative phylogenetic chronology.
- `repeat_insertions.tsv`: insertion sequence, exon position, length, repeat classification, RepeatMasker divergence when available, and fallback repeat-complexity metrics.
- `species_repeat_summary.tsv`: species-level repeat-insertion support across assemblies.
- `repeat_phylogenetic_summary.tsv`: shared repeat insertions and inferred origins on the ruminant tree.
- `report.html`: cross-linked interactive-style static report with phylogenetic tree, exon recovery boxes, per-species sections, event tables, repeat chronology and links to raw BLAST/data files.

## Confidence logic

The pipeline intentionally does not equate missing BLAST sequence with gene loss.

A low-recovery exon is called a **probable exon deletion** only when both neighboring exons support the same coherent GPRC6A locus and the intervening genomic interval is assembled with low N-content. Otherwise it remains **exon_unresolved**.

Explicit alignment indels are high/medium-confidence sequence events. An indel is called frame-shifting when its length modulo three is non-zero. Candidate large indels inferred from split HSP geometry are labeled separately and should be manually validated.

Premature stops are called at callable codons projected onto the pig CDS. The reconstructed target CDS is also translated so the first premature stop reached downstream of an uncompensated frame shift can be reported.

Potential splice-site disruptions are based on the two intronic bases immediately flanking well-recovered exon boundaries. They are deliberately labeled `potential_...` because rare splice classes and transcript annotation should be checked before making a definitive gene-loss claim.

## Repeat chronology

Repeat insertion sequences are sent to RepeatMasker when it is installed and configured. The analysis records repeat family/class, percentage of the insertion covered by repeat annotation and RepeatMasker divergence. Presence/absence of homologous insertions at the same pig-exon anchor is then mapped onto the species tree with the same parsimony framework as disruptive variants.

If RepeatMasker is unavailable, the fallback only labels sequence as tandem-repeat-like or low-complexity-like. It does not claim a TE family.

## Phylogenetic chronology

The Newick file supplied here is not a dated tree. Therefore the pipeline reports **relative chronology**, such as an event inferred at the MRCA of a named clade, and minimum independent origins/reversions under Fitch parsimony. It does not invent absolute ages in millions of years.

## Manual validation recommended for publication-grade gene-loss claims

For every candidate loss, especially a singleton event, inspect:

1. the raw BLAST HSPs;
2. all available assemblies of that species;
3. N-content and contig/scaffold boundaries around the locus;
4. whether the same event is present in close relatives at the homologous pig exon/codon position;
5. short-read or long-read evidence if available;
6. transcript/protein annotation where available;
7. repeat annotation if an insertion is implicated.

The HTML report is designed to make those cross-checks easy, but the strongest final claims should still be validated against raw reads when possible.
